﻿
using ToDoApp.Data;
using Task = ToDoApp.Data.Models.Task;
using TaskStatus = ToDoApp.Common.TaskStatus;

namespace ToDoApp.GraphQL
{
    public class Mutation
    {
        public async Task<Task> createTask([Service] ToDoAppDbContext context, CreateTaskInput input)
        {
            var task = new Task
            {
                Title = input.Title,
                Description = input.Description ?? string.Empty,
                Status = TaskStatus.Pending,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Tasks.Add(task);
            await context.SaveChangesAsync();

            return task;
        }

        public async Task<Task?> updateTaskStatus([Service] ToDoAppDbContext context, int id, TaskStatus status)
        {
            var task = await context.Tasks.FindAsync(id);
            if (task == null)
            {
                throw new GraphQLException("Task not found");
            }

            task.Status = status;
            task.UpdatedAt = DateTime.UtcNow;

            await context.SaveChangesAsync();

            return task;
        }

    }

    public record CreateTaskInput(string Title, string? Description);
}

