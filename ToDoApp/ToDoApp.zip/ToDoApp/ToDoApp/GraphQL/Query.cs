﻿using ToDoApp.Data;
using Task = ToDoApp.Data.Models.Task;

namespace ToDoApp.GraphQL
{
    public class Query
    {
        [GraphQLName("getAllTasks")]
        [UseProjection]
        [UseFiltering]
        [UseSorting]
        public IQueryable<Task> getAllTasks([Service] ToDoAppDbContext context)
        {
            return context.Tasks.OrderByDescending(t => t.CreatedAt);
        }

        [GraphQLName("getTaskById")]
        public async Task<Task?> getTaskById([Service] ToDoAppDbContext context, int id)
        {
            return await context.Tasks.FindAsync(id);
        }
    }
}
