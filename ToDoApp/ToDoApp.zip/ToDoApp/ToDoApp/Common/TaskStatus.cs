﻿namespace ToDoApp.Common
{
    public enum TaskStatus
    {
        Pending = 0,
        Completed = 1
    }
}
